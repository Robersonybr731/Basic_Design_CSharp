﻿namespace WP_12_7
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.粗細ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.顏色ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.筆刷ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.直線ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.點ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.繪圖工具ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.矩形ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.圓ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel4 = new System.Windows.Forms.ToolStripStatusLabel();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.兩倍ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.一半ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.調暗ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.增亮ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.亮暗調整ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.儲存ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.開啟新檔ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.開啟舊檔ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.檔案ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.顏色調整ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.負片ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.灰階ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.自訂ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.大小ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.畫筆ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.填滿ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.無填滿ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.編輯ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.復原ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.取消復原ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.顏色ToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.colorDialog2 = new System.Windows.Forms.ColorDialog();
            this.statusStrip1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(120, 34);
            this.toolStripMenuItem6.Text = "5";
            this.toolStripMenuItem6.Click += new System.EventHandler(this.toolStripMenuItem6_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(120, 34);
            this.toolStripMenuItem5.Text = "4";
            this.toolStripMenuItem5.Click += new System.EventHandler(this.toolStripMenuItem5_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(120, 34);
            this.toolStripMenuItem4.Text = "3";
            this.toolStripMenuItem4.Click += new System.EventHandler(this.toolStripMenuItem4_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(120, 34);
            this.toolStripMenuItem3.Text = "2";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(120, 34);
            this.toolStripMenuItem2.Text = "1";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // 粗細ToolStripMenuItem
            // 
            this.粗細ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem2,
            this.toolStripMenuItem3,
            this.toolStripMenuItem4,
            this.toolStripMenuItem5,
            this.toolStripMenuItem6});
            this.粗細ToolStripMenuItem.Name = "粗細ToolStripMenuItem";
            this.粗細ToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.粗細ToolStripMenuItem.Text = "粗細";
            // 
            // 顏色ToolStripMenuItem
            // 
            this.顏色ToolStripMenuItem.Name = "顏色ToolStripMenuItem";
            this.顏色ToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.顏色ToolStripMenuItem.Text = "顏色";
            this.顏色ToolStripMenuItem.Click += new System.EventHandler(this.顏色ToolStripMenuItem_Click);
            // 
            // 筆刷ToolStripMenuItem
            // 
            this.筆刷ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.顏色ToolStripMenuItem,
            this.粗細ToolStripMenuItem});
            this.筆刷ToolStripMenuItem.Name = "筆刷ToolStripMenuItem";
            this.筆刷ToolStripMenuItem.Size = new System.Drawing.Size(62, 28);
            this.筆刷ToolStripMenuItem.Text = "筆刷";
            // 
            // 直線ToolStripMenuItem
            // 
            this.直線ToolStripMenuItem.Name = "直線ToolStripMenuItem";
            this.直線ToolStripMenuItem.Size = new System.Drawing.Size(146, 34);
            this.直線ToolStripMenuItem.Text = "直線";
            this.直線ToolStripMenuItem.Click += new System.EventHandler(this.直線ToolStripMenuItem_Click);
            // 
            // 點ToolStripMenuItem
            // 
            this.點ToolStripMenuItem.Name = "點ToolStripMenuItem";
            this.點ToolStripMenuItem.Size = new System.Drawing.Size(146, 34);
            this.點ToolStripMenuItem.Text = "點";
            this.點ToolStripMenuItem.Click += new System.EventHandler(this.點ToolStripMenuItem_Click);
            // 
            // 繪圖工具ToolStripMenuItem
            // 
            this.繪圖工具ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.點ToolStripMenuItem,
            this.直線ToolStripMenuItem,
            this.矩形ToolStripMenuItem,
            this.圓ToolStripMenuItem});
            this.繪圖工具ToolStripMenuItem.Name = "繪圖工具ToolStripMenuItem";
            this.繪圖工具ToolStripMenuItem.Size = new System.Drawing.Size(98, 28);
            this.繪圖工具ToolStripMenuItem.Text = "繪圖工具";
            // 
            // 矩形ToolStripMenuItem
            // 
            this.矩形ToolStripMenuItem.Name = "矩形ToolStripMenuItem";
            this.矩形ToolStripMenuItem.Size = new System.Drawing.Size(146, 34);
            this.矩形ToolStripMenuItem.Text = "矩形";
            this.矩形ToolStripMenuItem.Click += new System.EventHandler(this.矩形ToolStripMenuItem_Click);
            // 
            // 圓ToolStripMenuItem
            // 
            this.圓ToolStripMenuItem.Name = "圓ToolStripMenuItem";
            this.圓ToolStripMenuItem.Size = new System.Drawing.Size(146, 34);
            this.圓ToolStripMenuItem.Text = "圓";
            this.圓ToolStripMenuItem.Click += new System.EventHandler(this.圓ToolStripMenuItem_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2,
            this.toolStripStatusLabel3,
            this.toolStripStatusLabel4});
            this.statusStrip1.Location = new System.Drawing.Point(0, 420);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new System.Windows.Forms.Padding(2, 0, 14, 0);
            this.statusStrip1.Size = new System.Drawing.Size(1092, 30);
            this.statusStrip1.TabIndex = 13;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(192, 23);
            this.toolStripStatusLabel1.Text = "toolStripStatusLabel1";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(192, 23);
            this.toolStripStatusLabel2.Text = "toolStripStatusLabel2";
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(192, 23);
            this.toolStripStatusLabel3.Text = "toolStripStatusLabel3";
            // 
            // toolStripStatusLabel4
            // 
            this.toolStripStatusLabel4.Name = "toolStripStatusLabel4";
            this.toolStripStatusLabel4.Size = new System.Drawing.Size(192, 23);
            this.toolStripStatusLabel4.Text = "toolStripStatusLabel4";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // 兩倍ToolStripMenuItem
            // 
            this.兩倍ToolStripMenuItem.Name = "兩倍ToolStripMenuItem";
            this.兩倍ToolStripMenuItem.Size = new System.Drawing.Size(146, 34);
            this.兩倍ToolStripMenuItem.Text = "兩倍";
            this.兩倍ToolStripMenuItem.Click += new System.EventHandler(this.兩倍ToolStripMenuItem_Click);
            // 
            // 一半ToolStripMenuItem
            // 
            this.一半ToolStripMenuItem.Name = "一半ToolStripMenuItem";
            this.一半ToolStripMenuItem.Size = new System.Drawing.Size(146, 34);
            this.一半ToolStripMenuItem.Text = "一半";
            this.一半ToolStripMenuItem.Click += new System.EventHandler(this.一半ToolStripMenuItem_Click);
            // 
            // 調暗ToolStripMenuItem
            // 
            this.調暗ToolStripMenuItem.Name = "調暗ToolStripMenuItem";
            this.調暗ToolStripMenuItem.Size = new System.Drawing.Size(146, 34);
            this.調暗ToolStripMenuItem.Text = "調暗";
            this.調暗ToolStripMenuItem.Click += new System.EventHandler(this.調暗ToolStripMenuItem_Click);
            // 
            // 增亮ToolStripMenuItem
            // 
            this.增亮ToolStripMenuItem.Name = "增亮ToolStripMenuItem";
            this.增亮ToolStripMenuItem.Size = new System.Drawing.Size(146, 34);
            this.增亮ToolStripMenuItem.Text = "增亮";
            this.增亮ToolStripMenuItem.Click += new System.EventHandler(this.增亮ToolStripMenuItem_Click);
            // 
            // 亮暗調整ToolStripMenuItem
            // 
            this.亮暗調整ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.增亮ToolStripMenuItem,
            this.調暗ToolStripMenuItem});
            this.亮暗調整ToolStripMenuItem.Name = "亮暗調整ToolStripMenuItem";
            this.亮暗調整ToolStripMenuItem.Size = new System.Drawing.Size(98, 28);
            this.亮暗調整ToolStripMenuItem.Text = "亮暗調整";
            // 
            // 儲存ToolStripMenuItem
            // 
            this.儲存ToolStripMenuItem.Name = "儲存ToolStripMenuItem";
            this.儲存ToolStripMenuItem.Size = new System.Drawing.Size(182, 34);
            this.儲存ToolStripMenuItem.Text = "儲存";
            this.儲存ToolStripMenuItem.Click += new System.EventHandler(this.儲存ToolStripMenuItem_Click);
            // 
            // 開啟新檔ToolStripMenuItem
            // 
            this.開啟新檔ToolStripMenuItem.Name = "開啟新檔ToolStripMenuItem";
            this.開啟新檔ToolStripMenuItem.Size = new System.Drawing.Size(182, 34);
            this.開啟新檔ToolStripMenuItem.Text = "開啟新檔";
            this.開啟新檔ToolStripMenuItem.Click += new System.EventHandler(this.開啟新檔ToolStripMenuItem_Click);
            // 
            // 開啟舊檔ToolStripMenuItem
            // 
            this.開啟舊檔ToolStripMenuItem.Name = "開啟舊檔ToolStripMenuItem";
            this.開啟舊檔ToolStripMenuItem.Size = new System.Drawing.Size(182, 34);
            this.開啟舊檔ToolStripMenuItem.Text = "開啟舊檔";
            this.開啟舊檔ToolStripMenuItem.Click += new System.EventHandler(this.開啟舊檔ToolStripMenuItem_Click);
            // 
            // 檔案ToolStripMenuItem
            // 
            this.檔案ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.開啟舊檔ToolStripMenuItem,
            this.開啟新檔ToolStripMenuItem,
            this.儲存ToolStripMenuItem});
            this.檔案ToolStripMenuItem.Name = "檔案ToolStripMenuItem";
            this.檔案ToolStripMenuItem.Size = new System.Drawing.Size(62, 28);
            this.檔案ToolStripMenuItem.Text = "檔案";
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.檔案ToolStripMenuItem,
            this.顏色調整ToolStripMenuItem,
            this.亮暗調整ToolStripMenuItem,
            this.大小ToolStripMenuItem,
            this.繪圖工具ToolStripMenuItem,
            this.筆刷ToolStripMenuItem,
            this.畫筆ToolStripMenuItem,
            this.編輯ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(6, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1092, 31);
            this.menuStrip1.TabIndex = 12;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 顏色調整ToolStripMenuItem
            // 
            this.顏色調整ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.負片ToolStripMenuItem,
            this.灰階ToolStripMenuItem,
            this.自訂ToolStripMenuItem});
            this.顏色調整ToolStripMenuItem.Name = "顏色調整ToolStripMenuItem";
            this.顏色調整ToolStripMenuItem.Size = new System.Drawing.Size(98, 28);
            this.顏色調整ToolStripMenuItem.Text = "顏色調整";
            // 
            // 負片ToolStripMenuItem
            // 
            this.負片ToolStripMenuItem.Name = "負片ToolStripMenuItem";
            this.負片ToolStripMenuItem.Size = new System.Drawing.Size(146, 34);
            this.負片ToolStripMenuItem.Text = "負片";
            this.負片ToolStripMenuItem.Click += new System.EventHandler(this.負片ToolStripMenuItem_Click);
            // 
            // 灰階ToolStripMenuItem
            // 
            this.灰階ToolStripMenuItem.Name = "灰階ToolStripMenuItem";
            this.灰階ToolStripMenuItem.Size = new System.Drawing.Size(146, 34);
            this.灰階ToolStripMenuItem.Text = "灰階";
            this.灰階ToolStripMenuItem.Click += new System.EventHandler(this.灰階ToolStripMenuItem_Click);
            // 
            // 自訂ToolStripMenuItem
            // 
            this.自訂ToolStripMenuItem.Name = "自訂ToolStripMenuItem";
            this.自訂ToolStripMenuItem.Size = new System.Drawing.Size(146, 34);
            this.自訂ToolStripMenuItem.Text = "自訂";
            this.自訂ToolStripMenuItem.Click += new System.EventHandler(this.自訂ToolStripMenuItem_Click);
            // 
            // 大小ToolStripMenuItem
            // 
            this.大小ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.一半ToolStripMenuItem,
            this.兩倍ToolStripMenuItem});
            this.大小ToolStripMenuItem.Name = "大小ToolStripMenuItem";
            this.大小ToolStripMenuItem.Size = new System.Drawing.Size(98, 28);
            this.大小ToolStripMenuItem.Text = "大小調整";
            // 
            // 畫筆ToolStripMenuItem
            // 
            this.畫筆ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator1,
            this.填滿ToolStripMenuItem,
            this.無填滿ToolStripMenuItem,
            this.顏色ToolStripMenuItem2});
            this.畫筆ToolStripMenuItem.Name = "畫筆ToolStripMenuItem";
            this.畫筆ToolStripMenuItem.Size = new System.Drawing.Size(62, 28);
            this.畫筆ToolStripMenuItem.Text = "畫筆";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(267, 6);
            // 
            // 填滿ToolStripMenuItem
            // 
            this.填滿ToolStripMenuItem.Name = "填滿ToolStripMenuItem";
            this.填滿ToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.填滿ToolStripMenuItem.Text = "填滿";
            this.填滿ToolStripMenuItem.Click += new System.EventHandler(this.填滿ToolStripMenuItem_Click);
            // 
            // 無填滿ToolStripMenuItem
            // 
            this.無填滿ToolStripMenuItem.Checked = true;
            this.無填滿ToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.無填滿ToolStripMenuItem.Name = "無填滿ToolStripMenuItem";
            this.無填滿ToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.無填滿ToolStripMenuItem.Text = "無填滿";
            this.無填滿ToolStripMenuItem.Click += new System.EventHandler(this.無填滿ToolStripMenuItem_Click);
            // 
            // 編輯ToolStripMenuItem
            // 
            this.編輯ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.復原ToolStripMenuItem,
            this.取消復原ToolStripMenuItem});
            this.編輯ToolStripMenuItem.Name = "編輯ToolStripMenuItem";
            this.編輯ToolStripMenuItem.Size = new System.Drawing.Size(62, 28);
            this.編輯ToolStripMenuItem.Text = "編輯";
            // 
            // 復原ToolStripMenuItem
            // 
            this.復原ToolStripMenuItem.Name = "復原ToolStripMenuItem";
            this.復原ToolStripMenuItem.Size = new System.Drawing.Size(182, 34);
            this.復原ToolStripMenuItem.Text = "復原";
            this.復原ToolStripMenuItem.Click += new System.EventHandler(this.復原ToolStripMenuItem_Click);
            // 
            // 取消復原ToolStripMenuItem
            // 
            this.取消復原ToolStripMenuItem.Name = "取消復原ToolStripMenuItem";
            this.取消復原ToolStripMenuItem.Size = new System.Drawing.Size(182, 34);
            this.取消復原ToolStripMenuItem.Text = "取消復原";
            this.取消復原ToolStripMenuItem.Click += new System.EventHandler(this.取消復原ToolStripMenuItem_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1092, 450);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 14;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseDown);
            this.pictureBox1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseMove);
            this.pictureBox1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseUp);
            // 
            // 顏色ToolStripMenuItem2
            // 
            this.顏色ToolStripMenuItem2.Name = "顏色ToolStripMenuItem2";
            this.顏色ToolStripMenuItem2.Size = new System.Drawing.Size(270, 34);
            this.顏色ToolStripMenuItem2.Text = "顏色";
            this.顏色ToolStripMenuItem2.Click += new System.EventHandler(this.顏色ToolStripMenuItem2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1092, 450);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = ".";
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem 粗細ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 顏色ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 筆刷ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 直線ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 點ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 繪圖工具ToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ToolStripMenuItem 兩倍ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 一半ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 調暗ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 增亮ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 亮暗調整ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 儲存ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 開啟新檔ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 開啟舊檔ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 檔案ToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 顏色調整ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 負片ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 灰階ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 大小ToolStripMenuItem;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolStripMenuItem 編輯ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 復原ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 取消復原ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 矩形ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 圓ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 畫筆ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem 填滿ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 無填滿ToolStripMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel4;
        private System.Windows.Forms.ToolStripMenuItem 自訂ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 顏色ToolStripMenuItem2;
        private System.Windows.Forms.ColorDialog colorDialog2;
    }
}

